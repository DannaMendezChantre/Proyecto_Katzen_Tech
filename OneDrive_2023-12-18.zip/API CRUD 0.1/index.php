<?php
$host = "localhost";
$usuario = "root";
$password = "";
$basededatos = "computer_advance_ultima";

$conexion = new mysqli($host, $usuario, $password, $basededatos);

if ($conexion->connect_error) {
    die("Conexión Establecida" . $conexion->connect_error);
}

header("Content-Type: application/json");
$metodo = $_SERVER['REQUEST_METHOD'];
print_r($metodo);

$patch = isset($_SERVER['PATH_INFO']) ? $_SERVER['PATH_INFO'] : '/';

$buscarId = explode('/', $patch);

$id = ($patch == '/') ? end($buscarId) : null;

switch ($metodo) {

    //Select Usuarios
    case 'GET':
        echo "consulta de registros - GET";
        consultas($conexion);
        break;

    //Insert Usuarios
    case 'POST':
        echo "insertar registros - POST";
        insertar($conexion);
        break;

    //Update Usuarios
    case 'PUT':
        echo "Edición de registros - PUT";
        break;

    //Delete Usuarios
    case 'DELETE':
        echo "Borrado de registros - DELETE";
        borrar($conexion, $id);
        break;

    default:
        echo "Metodo no permitido";
        break;
}

function consultas($conexion)
{
    $sql = "SELECT * FROM usuarios";
    $resultado = $conexion->query($sql);

    if ($resultado) {
        $datos = array();
        while ($fila = $resultado->fetch_assoc()) {
            $datos[] = $fila;
        }
        echo json_encode($datos);
    }
}

function insertar($conexion)
{
    $dato = json_decode(file_get_contents('php://input'), true);
    $nombre = $dato['nombre'];
    print_r($nombre);

    $sql = "INSERT INTO usuarios (nombre) VALUES ('$nombre')";
    $resultado = $conexion->query($sql);
    if ($resultado) {
        echo "Registro insertado correctamente.";
    } else {
        echo "Error al insertar el registro: " . $conexion->error;
    }
}

function borrar($conexion, $id)
{
    if ($id !== null) {
        $id = $conexion->real_escape_string($id);
        $sql = "DELETE FROM usuarios WHERE id = '$id'";
        $resultado = $conexion->query($sql);

        if ($resultado) {
            echo "Registro eliminado correctamente.";
        } else {
            echo "Error al eliminar el registro: " . $conexion->error;
        }
    } else {
        echo "ID no proporcionado para borrar";
    }
}
?>



