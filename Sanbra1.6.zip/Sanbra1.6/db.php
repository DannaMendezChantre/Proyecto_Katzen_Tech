<?php

$conexion=mysqli_connect("localhost","root","","sanbra") or die ("erorr de conexion");

echo "conectado"

?>